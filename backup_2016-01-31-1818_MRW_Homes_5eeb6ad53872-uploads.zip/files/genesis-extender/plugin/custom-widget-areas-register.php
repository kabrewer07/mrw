<?php
/**
 * Register Custom Widget Areas.
 */
