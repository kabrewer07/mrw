<?php
/**
 * Build and register EZ Widget Area structures.
 */
 
/**
 * Register EZ Widget Areas
 */
//end wp-content/uploads/genesis-extender/plugin/ez-structures.php