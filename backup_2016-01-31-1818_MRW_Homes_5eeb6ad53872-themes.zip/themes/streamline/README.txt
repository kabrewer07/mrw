<strong>STREMLINE CHILD THEME</strong>
<a href="http://www.studiopress.com/themes/streamline">http://www.studiopress.com/themes/streamline</a>

<strong>INSTALL</strong>
1. Upload the Streamline child theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Streamline theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

<strong>WIDGET AREAS</strong>
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Content Layout option.
Footer #1 - This is the first column of the footer section.
Footer #2 - This is the second column of the footer section.
Footer #3 - This is the third column of the footer section.
Newsletter - This is the newsletter section below the navigation.
Home Featured #1 - This is the featured #1 column on the homepage.
Home Featured #2 - This is the featured #2 column on the homepage.
Home Featured #3 - This is the featured #3 column on the homepage.
After Post - This is the after post section.

<strong>FEATURED IMAGES</strong>
By default WordPress will create a default thumbnail image for each image you upload and the size can be specified in your dashboard under Settings > Media. In addition, the Streamline child theme creates the following thumbnail images you'll see below, which are defined (and can be modified) in the functions.php file. These are the recommended thumbnail sizes that are used on the Streamline child theme demo site.

home-featured - 255px by 80px
post-image - 642px by 250px

<strong>SUPPORT</strong>
Please visit <a href="http://www.studiopress.com/support">http://www.studiopress.com/support</a> for theme support.