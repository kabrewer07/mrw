<?php
/**
 * The file is a currently a placeholder for code coming in a future version of Genesis.
 *
 * @category Genesis
 * @package  Layouts
 * @author   StudioPress
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL-2.0+
 * @link     http://www.studiopress.com/themes/genesis
 *
 * @ignore
 */