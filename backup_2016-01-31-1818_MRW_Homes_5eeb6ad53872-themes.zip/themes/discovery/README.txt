<strong>AGENTPRESS CHILD THEME</strong>
<a href="http://www.studiopress.com/themes/agentpress">http://www.studiopress.com/themes/agentpress</a>

<strong>INSTALL</strong>
1. Upload the AgentPress child theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the AgentPress theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

<strong>WIDGET AREAS</strong>
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar, Sidebar/Content, Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Secondary Sidebar - This is the secondary sidebar if you are using the Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Top Search - This is the full-width horizontal search section.
Slider - This is the slider section.
Property Search - This is the property search section.
Welcome - This is the welcome section.
Properties - This is the properties section.
Communities - This is the communities section.
Featured Bottom Left - This is the featured bottom left section.
Featured Bottom Right - This is the featured bottom right section.
Disclaimer - This is the disclaimer section.
Footer #1 - This is the first column of the footer section.
Footer #2 - This is the second column of the footer section.
Footer #3 - This is the third column of the footer section.

<strong>FEATURED IMAGES</strong>
By default WordPress will create a default thumbnail image for each image you upload and the size can be specified in your dashboard under Settings > Media. In addition, the AgentPress child theme creates the following thumbnail images you'll see below, which are defined (and can be modified) in the functions.php file. These are the recommended thumbnail sizes that are used on the AgentPress child theme demo site.

communities - 125px by 80px
featured - 100px by 100px
properties - 280px by 200px
slider - 590px by 300px

<strong>SUPPORT</strong>
Please visit <a href="http://www.studiopress.com/support">http://www.studiopress.com/support</a> for theme support.