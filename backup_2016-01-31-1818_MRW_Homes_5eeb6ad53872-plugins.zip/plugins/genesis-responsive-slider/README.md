# genesis-responsive-slider
Plugin: Genesis Responsive Slider
